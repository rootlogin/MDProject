/*
 * Copyright (c) 2016.3.$today.day-$today.hour24:5:40
 */

package com.gohon.material.Handlers;

/**
 * Created by liuyonglong on 16/3/23.
 */
public class UserHandlers {

    public String toString(int age){
        return String.valueOf(age);
    }
}
