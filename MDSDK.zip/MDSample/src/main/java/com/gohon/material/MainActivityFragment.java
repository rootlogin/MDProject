package com.gohon.material;

import android.databinding.DataBindingUtil;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.gohon.material.Adapter.UserAdapter;
import com.gohon.material.Events.UserEvents;
import com.gohon.material.Handlers.UserHandlers;
import com.gohon.material.POJO.User;
import com.gohon.material.databinding.FragmentMainBinding;
import com.material.sdk.http.HttpApi;
import com.material.sdk.http.volley.IVolleyApi;

import java.util.ArrayList;
import java.util.List;

/**
 * A placeholder fragment containing a simple view.
 */
public class MainActivityFragment extends Fragment {
    MainActivity mainActivity;
    private List<User> userList = new ArrayList<>();
    private UserAdapter adapter;


    public MainActivityFragment() {

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainActivity = (MainActivity) getActivity();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        FragmentMainBinding fragmentMainBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_main, container, false);
        fragmentMainBinding.setUser(mainActivity.user);
        View rootView = fragmentMainBinding.getRoot();
        RecyclerView recyclerView = (RecyclerView) rootView.findViewById(R.id.recycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new UserAdapter(userList);
        recyclerView.setAdapter(adapter);

        UserEvents events = new UserEvents(this, mainActivity.user);
        UserHandlers handlers = new UserHandlers();
        fragmentMainBinding.setEvent(events);
        fragmentMainBinding.setHandler(handlers);
        testVolley();

        return rootView;
    }

    public void onCreateListData() {
        for (int i = 0; i < 10; i++) {
            User user = new User("name"+i,i);
            userList.add(user);
        }
        adapter.notifyDataSetChanged();
    }

    private void testVolley(){
//        HttpFactoryAPI.getInstance().getVolleyAPI().requestGet(new IVolleyRequestAPI.IRequest() {
//            @Override
//            public Request onRequest() {
//                return new CustomVolleyRequest<String>(Request.Method.GET, "http://www.jcodecraeer.com/a/anzhuokaifa/androidkaifa/2015/0201/2394.html", String.class, new Response.Listener<String>() {
//
//                    @Override
//                    public void onResponse(String response) {
//                        Log.e("返回",response);
//                        Toast.makeText(getActivity(),response,Toast.LENGTH_SHORT).show();
//                    }
//                }, new Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                    }
//                });
//            }
//        });

        HttpApi.getInstance().getVolleyAPI().requestGet(new IVolleyApi.IRequest() {
            @Override
            public Request onRequest() {

                StringRequest stringRequest = new StringRequest(Request.Method.GET, "http://www.jcodecraeer.com/a/anzhuokaifa/androidkaifa/2015/0201/2394.html", new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        System.out.println(response);
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                });
                stringRequest.setTag(stringRequest);

                return stringRequest;
            }
        });

    }

}
