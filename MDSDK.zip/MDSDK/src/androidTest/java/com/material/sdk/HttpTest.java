package com.material.sdk;

import com.material.sdk.http.HttpFactory;
import com.material.sdk.http.HttpFactoryAPI;

/**
 * Created by 勾魂 on 2016/3/29.
 */
public class HttpTest {

    public void httpTest(){
        HttpFactoryAPI.getInstance().getVolleyAPI().requestGet(null);
        HttpFactory httpFactory = new HttpFactoryAPI();
        httpFactory.getVolleyAPI().requestGet(null);

    }

    public void vollTest(){

    }
}
