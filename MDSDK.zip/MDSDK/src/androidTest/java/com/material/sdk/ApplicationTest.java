package com.material.sdk;

import android.app.Application;
import android.test.ApplicationTestCase;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;
import com.material.sdk.http.volley.CustomVolleyRequest;

import org.junit.Test;

/**
 * <a href="http://d.android.com/tools/testing/testing_android.html">Testing Fundamentals</a>
 */

public class ApplicationTest extends ApplicationTestCase<Application> {
    public ApplicationTest() {
        super(Application.class);
    }


    @Test
    public void TestVolley(){
        RequestQueue newRequestQueue = Volley.newRequestQueue(getContext());
        CustomVolleyRequest customVolleyRequest = new CustomVolleyRequest(Request.Method.GET,"https://www.baidu.com/",String.class,new Response.Listener<String>()
        {

            @Override
            public void onResponse(String response)
            {
                Log.e("TAG", response);

            }
        }, new Response.ErrorListener()
        {
            @Override
            public void onErrorResponse(VolleyError error)
            {
                Log.e("TAG", error.getMessage(), error);
            }
        });

       Request<String> request = newRequestQueue.add(customVolleyRequest);
        request.getTag();
    }
}