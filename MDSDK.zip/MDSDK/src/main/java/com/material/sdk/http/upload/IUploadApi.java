/*
 * Copyright (c) 2016.3.$today.day-$today.hour24:7:54
 */

package com.material.sdk.http.upload;

/**
 * Created by liuyonglong on 16/3/30.
 */
public class IUploadApi {
}
