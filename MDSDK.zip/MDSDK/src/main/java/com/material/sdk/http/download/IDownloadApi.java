/*
 * Copyright (c) 2016.3.$today.day-$today.hour24:6:17
 */

package com.material.sdk.http.download;

/**
 * Created by liuyonglong on 16/3/30.
 */
public interface IDownloadApi {
}
